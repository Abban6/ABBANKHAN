void replaceChar(char *name, char oldChar, char newChar);
char * replaceCharCopy(char *s, char oldChar, char newChar);
void removeChar(char *s, char c);
char * removeCharCopy(char *s, char c);
char **lengthSplit(char *s, int n);
void print2DStr(char **splitStr);