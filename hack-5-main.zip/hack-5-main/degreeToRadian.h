
#include<math.h>
// Function change degree to Radians
double degreesToRadians(double degree){
    degree =  (degree * M_PI)/180;
    return degree;
}

